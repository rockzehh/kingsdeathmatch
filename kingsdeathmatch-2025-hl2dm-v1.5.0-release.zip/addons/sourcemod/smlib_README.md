# smlib
[![Build Status](https://travis-ci.org/bcserv/smlib.svg)](https://travis-ci.org/bcserv/smlib)

Function Stock Library for Sourcemod with over 350 functions.

**URL:**        http://www.sourcemodplugins.org/smlib/

**Discussion:** https://forums.alliedmods.net/showthread.php?t=148387

**Contribution guidelines:** [CONTRIBUTING.md](CONTRIBUTING.md)
